//
//  TestDogKit.h
//  TestDogKit
//
//  Created by Branko Grbic on 10.5.22..
//

#import <Foundation/Foundation.h>

//! Project version number for TestDogKit.
FOUNDATION_EXPORT double TestDogKitVersionNumber;

//! Project version string for TestDogKit.
FOUNDATION_EXPORT const unsigned char TestDogKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestDogKit/PublicHeader.h>


